# NeverLoseBr0 v0.2.0

Minecraft 1.21.11 / Fabric / Java 21.

## Included
- Akrien/Neverlose-inspired dark navy + cyan ClickGUI.
- Right Shift opens the GUI.
- Five categories and a searchable module registry.
- 38 client-side utility, HUD, visual and practice-helper module entries.
- Clickable module states and a Panic switch.
- Mouse-wheel-independent keyboard list navigation (Up/Down).
- Fabric client entrypoint and Gradle project.

## Important implementation status
This is a working source foundation and module registry, **not a finished combat cheat**. Module switches currently manage client UI state; only the registry and interface are implemented. Automatic player targeting/attacking, server-side rotation spoofing, anti-cheat bypasses, reach manipulation and exploit functionality are intentionally not included. Use the client only where server rules permit client modifications.

## Build
Install JDK 21 and Gradle 9.x, then run:

```bash
gradle build
```

The remapped mod JAR should appear under `build/libs/`. The project has not been compiled or tested in a live Minecraft instance in this environment.
